# SOME NOTES

pushing the local repo to a new branch
git push --set-upstream origin <'name the new branch'>

# Recording video of the screen

ctrl + alt + R to record the window

# Github

force main to align with repo
git reset --hard origin/main

# Heroku database reset

```
heroku pg:reset
heroku pg:push project3_db DATABASE_URL
```
